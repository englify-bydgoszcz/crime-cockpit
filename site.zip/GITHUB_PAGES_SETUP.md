# Jednorazowe uruchomienie GitHub Pages

1. Utwórz repozytorium `crime-cockpit` w organizacji / koncie `englify-bydgoszcz`.
2. Najbezpieczniej dla GitHub Free: repo **publiczne**; frontendowy demo snapshot jest oczyszczony z prywatnych notatek i nie zawiera tokenu ani URL API.
3. Po pierwszym pushu wejdź w **Settings → Pages**.
4. W `Build and deployment` wybierz **Deploy from a branch**.
5. Wybierz `main` i `/ (root)`, zapisz.
6. Od tej chwili każdy push do `main` automatycznie aktualizuje podgląd.

Token i URL Apps Script ustawiasz już na stronie Cockpitu w ustawieniach; są trzymane w localStorage Twojej przeglądarki.
