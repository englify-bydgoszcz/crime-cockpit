/**
 * Crime Cockpit — Read-only API v5.3.0 · cockpit v6.3.0
 * Backend: Google Sheet "Ranking kryminałów"
 * Frontend: local Crime Cockpit v6.0 via JSONP.
 *
 * ARCHITECTURE
 * - READ ONLY: no doPost, no sheet mutations.
 * - Header-driven library reader: column insertions/reordering do not break the API.
 * - Unknown future columns are exposed under book.extra and schema.extraFields.
 * - UI Manifest controls labels/modules/feature flags without frontend rewrites.
 * - r2: UI Manifest + Coverage Map are header-driven (no fixed row windows).
 * - Media is a presentation-only layer and never affects scoring.
 * - Missing optional modules degrade gracefully instead of failing the whole payload.
 */
const CRIME_COCKPIT = Object.freeze({
  SPREADSHEET_ID: '1_9kUvs64NwUfF03hmq9bjlq94eIgnaXOnjiiFgLRCrU',
  TOKEN_PROPERTY: 'CRIME_COCKPIT_TOKEN',
  SCHEMA_VERSION: '5.3.0',
  FRONTEND_MIN_VERSION: '6.3.0'
});

function doGet(e) {
  const startedAt = Date.now();
  const params = (e && e.parameter) || {};
  const callback = validateCallback_(params.prefix || params.callback || '');
  const scope = str_(params.scope || 'full').toLowerCase();
  let payload;
  try {
    authorize_(params.token || '');
    if (scope === 'ping') payload = buildPingPayload_();
    else if (scope === 'core') payload = buildCrimeCockpitCorePayload_();
    else if (scope === 'extras') payload = buildCrimeCockpitExtrasPayload_();
    else if (scope === 'modules') payload = buildCrimeCockpitModulesPayload_(params.keys || '');
    else payload = buildCrimeCockpitPayload_(); // legacy / v4.1 compatibility
  } catch (err) {
    payload = {
      ok: false,
      schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
      generatedAt: new Date().toISOString(),
      scope,
      error: String(err && err.message ? err.message : err)
    };
  }

  if (payload && typeof payload === 'object') payload.serverMs = Date.now() - startedAt;
  const json = JSON.stringify(payload);
  if (callback) {
    return ContentService
      .createTextOutput(`${callback}(${json});`)
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

function authorize_(token) {
  const expected = PropertiesService.getScriptProperties().getProperty(CRIME_COCKPIT.TOKEN_PROPERTY);
  if (!expected) throw new Error('BACKEND_NOT_CONFIGURED: ustaw CRIME_COCKPIT_TOKEN w Script Properties.');
  if (!token || token !== expected) throw new Error('UNAUTHORIZED');
}

function validateCallback_(name) {
  if (!name) return '';
  if (!/^[A-Za-z_$][0-9A-Za-z_$]*(\.[A-Za-z_$][0-9A-Za-z_$]*)*$/.test(name)) {
    throw new Error('INVALID_CALLBACK');
  }
  return name;
}

function buildPingPayload_() {
  return {
    ok: true,
    schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
    frontendMinVersion: CRIME_COCKPIT.FRONTEND_MIN_VERSION,
    generatedAt: new Date().toISOString(),
    scope: 'ping',
    source: 'LIVE · GOOGLE SHEETS'
  };
}

function buildCrimeCockpitCorePayload_() {
  const ss = SpreadsheetApp.openById(CRIME_COCKPIT.SPREADSHEET_ID);
  const ui = safeModule_(() => readUiManifest_(ss), defaultUi_());
  const media = safeModule_(() => readMedia_(ss), {});
  const libraryResult = readLibrary_(ss, media);
  const library = libraryResult.books;
  const current = readCurrent_(ss, library);
  const candidates = library
    .filter(x => ['PROMOTE', 'WATCH'].includes(x.lifecycle) && Number.isFinite(x.decision))
    .sort((a,b) => (a.decisionRank || 9999) - (b.decisionRank || 9999) || b.decision - a.decision)
    .slice(0, 30);
  return {
    ok: true,
    schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
    frontendMinVersion: CRIME_COCKPIT.FRONTEND_MIN_VERSION,
    generatedAt: new Date().toISOString(),
    scope: 'core',
    source: 'LIVE · GOOGLE SHEETS',
    ui,
    capabilities: ui.features,
    schema: {
      libraryFields: libraryResult.headers,
      knownFields: libraryResult.knownHeaders,
      extraFields: libraryResult.extraHeaders
    },
    current,
    decision: safeModule_(() => readDecision_(ss), {}),
    session: safeModule_(() => readSession_(ss), {}),
    system: {
      books: library.length,
      read: library.filter(x => x.read).length,
      eligible: library.filter(x => x.eligibility === 'ELIGIBLE').length,
      auditIssues: library.filter(x => ['TODO','PARTIAL'].includes(x.auditStatus)).length
    },
    lifecycle: lifecycleCounts_(library),
    health: safeModule_(() => readSystemHealth_(ss), {overall:'UNKNOWN', pass:0, warn:0, fail:0, checks:[]}),
    candidates,
    library,
    readingRoom: safeModule_(() => readReadingRoom_(ss), []),
    achievements: safeModule_(() => readAchievements_(ss), []),
    modules: {}
  };
}

function buildCrimeCockpitExtrasPayload_() {
  const ss = SpreadsheetApp.openById(CRIME_COCKPIT.SPREADSHEET_ID);
  return {
    ok: true,
    schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
    frontendMinVersion: CRIME_COCKPIT.FRONTEND_MIN_VERSION,
    generatedAt: new Date().toISOString(),
    scope: 'extras',
    coverage: safeModule_(() => readCoverage_(ss), {metadata:[], blindSpots:[], enrichment:[]}),
    calibration: safeModule_(() => readCalibration_(ss), {tests:0, history:[]}),
    simulator: safeModule_(() => readDecisionSimulator_(ss), {rows:[]}),
    learning: safeModule_(() => readLearningLedger_(ss), {events:0, items:[]}),
    missions: safeModule_(() => readMissions_(ss), []),
    interactions: safeModule_(() => readTasteInteractions_(ss), []),
    postmortem: safeModule_(() => readRecommendationPostmortem_(ss), {closed:0, waiting:0, bigMisses:0, items:[]})
  };
}

function buildCrimeCockpitModulesPayload_(keysParam) {
  const ss = SpreadsheetApp.openById(CRIME_COCKPIT.SPREADSHEET_ID);
  const specs = moduleSpecs_();
  const requested = String(keysParam || '').split(',').map(x => x.trim()).filter(x => specs[x]);
  const keys = requested.length ? requested : Object.keys(specs);
  return {
    ok: true,
    schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
    frontendMinVersion: CRIME_COCKPIT.FRONTEND_MIN_VERSION,
    generatedAt: new Date().toISOString(),
    scope: 'modules',
    modules: readSelectedModules_(ss, keys)
  };
}

function buildCrimeCockpitPayload_() {
  const ss = SpreadsheetApp.openById(CRIME_COCKPIT.SPREADSHEET_ID);
  const ui = safeModule_(() => readUiManifest_(ss), defaultUi_());
  const media = safeModule_(() => readMedia_(ss), {});
  const libraryResult = readLibrary_(ss, media);
  const library = libraryResult.books;
  const current = readCurrent_(ss, library);
  const candidates = library
    .filter(x => ['PROMOTE', 'WATCH'].includes(x.lifecycle) && Number.isFinite(x.decision))
    .sort((a,b) => (a.decisionRank || 9999) - (b.decisionRank || 9999) || b.decision - a.decision)
    .slice(0, 30);

  return {
    ok: true,
    schemaVersion: CRIME_COCKPIT.SCHEMA_VERSION,
    frontendMinVersion: CRIME_COCKPIT.FRONTEND_MIN_VERSION,
    generatedAt: new Date().toISOString(),
    source: 'LIVE · GOOGLE SHEETS',
    ui,
    capabilities: ui.features,
    schema: {
      libraryFields: libraryResult.headers,
      knownFields: libraryResult.knownHeaders,
      extraFields: libraryResult.extraHeaders
    },
    current,
    decision: safeModule_(() => readDecision_(ss), {}),
    session: safeModule_(() => readSession_(ss), {}),
    system: {
      books: library.length,
      read: library.filter(x => x.read).length,
      eligible: library.filter(x => x.eligibility === 'ELIGIBLE').length,
      auditIssues: library.filter(x => ['TODO','PARTIAL'].includes(x.auditStatus)).length
    },
    lifecycle: lifecycleCounts_(library),
    coverage: safeModule_(() => readCoverage_(ss), {metadata:[], blindSpots:[], enrichment:[]}),
    calibration: safeModule_(() => readCalibration_(ss), {tests:0, history:[]}),
    health: safeModule_(() => readSystemHealth_(ss), {overall:'UNKNOWN', pass:0, warn:0, fail:0, checks:[]}),
    simulator: safeModule_(() => readDecisionSimulator_(ss), {rows:[]}),
    learning: safeModule_(() => readLearningLedger_(ss), {events:0, items:[]}),
    missions: safeModule_(() => readMissions_(ss), []),
    interactions: safeModule_(() => readTasteInteractions_(ss), []),
    postmortem: safeModule_(() => readRecommendationPostmortem_(ss), {closed:0, waiting:0, bigMisses:0, items:[]}),
    modules: safeModule_(() => readModuleBundle_(ss), {}),
    candidates,
    library,
    readingRoom: safeModule_(() => readReadingRoom_(ss), []),
    achievements: safeModule_(() => readAchievements_(ss), [])
  };
}

function readLibrary_(ss, media) {
  const sh = requireSheet_(ss, 'Baza książek');
  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return {books:[], headers:[], knownHeaders:[], extraHeaders:[]};

  const headers = sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(str_);
  const map = headerMap_(headers);
  const rows = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();
  const known = new Set([
    'Plan #','Tytuł','Autor','GR /5','LC /10','Community /5','Przeczytane','Moja ocena','Data ukończenia',
    'Warstwa','Seria','Tom','Kraj','Epoka','Podgatunek','Detektyw / protagonista','Cold case','Fair play','Twisty',
    'Psychologia','Mrok','Tempo','Humor','Predykcja','Confidence','Eligibility','Book ID','Language Status',
    'Language Friction','Data Confidence','Discovery Signal','Freshness','Core Book Fit','Book Fit (beta)','Read Next Score',
    'Why now','Score Status','GR N','LC N','Rating checked','Rating confidence','Work Type','Series Mode','Audit Priority',
    'Audit Flags','Audit Status','GR Confidence','LC Confidence','Recommendation Gate','Gate Reason','Series Safety',
    'Rating Data State','Recommendation Risk','Preflight Requirement','Last Preflight','Preflight Verdict','Preflight Source',
    'Safety Risk','Preflight Standard','Preflight Age (days)','Last Preflight Decision','Exploration Value','Diversity Value',
    'Information Gain','Series Momentum','Decision Score','Lifecycle','Lifecycle Reason','Taste Fit','Community Quality',
    'Session Boost','Decision Rank','Decision Top %','Novelty Load','Metadata Debt','Missing Metadata','Decision Why',
    'Decision Confidence','Confidence Band','Confidence Why',
    'Vault EPUB','Vault Language','Vault Edition ID','Vault State','Vault UI Signal','Preload Pressure','Preload State','Preload Why','Vault Snapshot','Vault Model Effect'
  ]);

  const books = rows.filter(r => str_(getByHeader_(r,map,['Tytuł']))).map(r => {
    const id = str_(getByHeader_(r,map,['Book ID']));
    const extra = {};
    headers.forEach((h,i) => {
      if (!h || known.has(h)) return;
      const v = r[i];
      if (v !== '' && v != null) extra[h] = dateOrString_(v);
    });
    const mediaEntry = media[id] || {};
    return {
      id,
      title: str_(getByHeader_(r,map,['Tytuł'])),
      author: str_(getByHeader_(r,map,['Autor'])),
      read: getByHeader_(r,map,['Przeczytane']) === true,
      rating: numOrNull_(getByHeader_(r,map,['Moja ocena'])),
      community: numOrNull_(getByHeader_(r,map,['Community /5'])),
      finishedAt: dateOrString_(getByHeader_(r,map,['Data ukończenia'])),
      layer: str_(getByHeader_(r,map,['Warstwa'])),
      series: str_(getByHeader_(r,map,['Seria'])),
      volume: nullable_(getByHeader_(r,map,['Tom'])),
      country: str_(getByHeader_(r,map,['Kraj'])),
      era: str_(getByHeader_(r,map,['Epoka'])),
      subgenre: str_(getByHeader_(r,map,['Podgatunek'])),
      protagonist: str_(getByHeader_(r,map,['Detektyw / protagonista'])),
      prediction: numOrNull_(getByHeader_(r,map,['Predykcja'])),
      confidence: numOrNull_(getByHeader_(r,map,['Confidence'])),
      eligibility: str_(getByHeader_(r,map,['Eligibility'])),
      language: str_(getByHeader_(r,map,['Language Status'])),
      languageFriction: numOrNull_(getByHeader_(r,map,['Language Friction'])),
      dataConfidence: numOrNull_(getByHeader_(r,map,['Data Confidence'])),
      discoverySignal: numOrNull_(getByHeader_(r,map,['Discovery Signal'])),
      freshness: numOrNull_(getByHeader_(r,map,['Freshness'])),
      bookFit: numOrNull_(getByHeader_(r,map,['Core Book Fit','Book Fit (beta)'])),
      readNext: numOrNull_(getByHeader_(r,map,['Read Next Score'])),
      whyNow: str_(getByHeader_(r,map,['Why now'])),
      workType: str_(getByHeader_(r,map,['Work Type'])),
      seriesMode: str_(getByHeader_(r,map,['Series Mode'])),
      auditStatus: str_(getByHeader_(r,map,['Audit Status'])),
      gate: str_(getByHeader_(r,map,['Recommendation Gate'])),
      gateReason: str_(getByHeader_(r,map,['Gate Reason'])),
      seriesSafety: str_(getByHeader_(r,map,['Series Safety'])),
      risk: str_(getByHeader_(r,map,['Safety Risk','Recommendation Risk'])),
      preflightRequirement: str_(getByHeader_(r,map,['Preflight Requirement'])),
      lastPreflight: dateOrString_(getByHeader_(r,map,['Last Preflight'])),
      preflightVerdict: str_(getByHeader_(r,map,['Preflight Verdict'])),
      preflightSource: str_(getByHeader_(r,map,['Preflight Source'])),
      preflightStandard: str_(getByHeader_(r,map,['Preflight Standard'])),
      infoGain: numOrNull_(getByHeader_(r,map,['Information Gain'])),
      exploration: numOrNull_(getByHeader_(r,map,['Exploration Value'])),
      diversity: numOrNull_(getByHeader_(r,map,['Diversity Value'])),
      momentum: numOrNull_(getByHeader_(r,map,['Series Momentum'])),
      decision: numOrNull_(getByHeader_(r,map,['Decision Score'])),
      lifecycle: str_(getByHeader_(r,map,['Lifecycle'])),
      lifecycleReason: str_(getByHeader_(r,map,['Lifecycle Reason'])),
      tasteFit: numOrNull_(getByHeader_(r,map,['Taste Fit'])),
      communityQuality: numOrNull_(getByHeader_(r,map,['Community Quality'])),
      sessionBoost: numOrNull_(getByHeader_(r,map,['Session Boost'])),
      decisionRank: numOrNull_(getByHeader_(r,map,['Decision Rank'])),
      decisionTopPct: numOrNull_(getByHeader_(r,map,['Decision Top %'])),
      noveltyLoad: numOrNull_(getByHeader_(r,map,['Novelty Load'])),
      metadataDebt: numOrNull_(getByHeader_(r,map,['Metadata Debt'])),
      missingMetadata: str_(getByHeader_(r,map,['Missing Metadata'])),
      decisionWhy: str_(getByHeader_(r,map,['Decision Why'])),
      decisionConfidence: numOrNull_(getByHeader_(r,map,['Decision Confidence'])),
      confidenceBand: str_(getByHeader_(r,map,['Confidence Band'])),
      confidenceWhy: str_(getByHeader_(r,map,['Confidence Why'])),
      vaultEpub: bool_(getByHeader_(r,map,['Vault EPUB'])),
      vaultLanguage: str_(getByHeader_(r,map,['Vault Language'])),
      vaultEditionId: str_(getByHeader_(r,map,['Vault Edition ID'])),
      vaultState: str_(getByHeader_(r,map,['Vault State'])),
      vaultSignal: str_(getByHeader_(r,map,['Vault UI Signal'])),
      preloadPressure: numOrNull_(getByHeader_(r,map,['Preload Pressure'])),
      preloadState: str_(getByHeader_(r,map,['Preload State'])),
      preloadWhy: str_(getByHeader_(r,map,['Preload Why'])),
      vaultSnapshot: str_(getByHeader_(r,map,['Vault Snapshot'])),
      vaultModelEffect: str_(getByHeader_(r,map,['Vault Model Effect'])),
      coverUrl: str_(mediaEntry.coverUrl),
      coverSourceUrl: str_(mediaEntry.sourceUrl),
      coverSource: str_(mediaEntry.source),
      coverConfidence: numOrNull_(mediaEntry.confidence),
      extra
    };
  });

  const knownHeaders = headers.filter(h => known.has(h));
  const extraHeaders = headers.filter(h => h && !known.has(h));
  return {books, headers, knownHeaders, extraHeaders};
}

function readCurrent_(ss, library) {
  const book = library.find(x => x.lifecycle === 'CURRENT NEXT') || library.find(x => !x.read) || {};
  const snapshot = latestRecommendationSnapshot_(ss, book.id);
  return Object.assign({}, book, {
    preflight: snapshot.gate ? `${snapshot.gate}${snapshot.preflightMode ? ' · ' + snapshot.preflightMode : ''}` : (book.preflightVerdict || ''),
    risk: snapshot.risk || book.risk || '',
    prediction: snapshot.prediction != null ? snapshot.prediction : book.prediction,
    confidence: snapshot.confidence != null ? snapshot.confidence : book.confidence,
    decisionSnapshot: snapshot.decisionSnapshot,
    modeSnapshot: snapshot.modeSnapshot,
    continuity: snapshot.continuity || '',
    preflightSource: snapshot.source || book.preflightSource || ''
  });
}

function latestRecommendationSnapshot_(ss, bookId) {
  const sh = ss.getSheetByName('Log rekomendacji');
  if (!sh || sh.getLastRow() < 3) return {};
  const table = readTable_(sh, 2);
  const map = table.map;
  for (let i = table.rows.length - 1; i >= 0; i--) {
    const r = table.rows[i];
    if (str_(getByHeader_(r,map,['Book ID'])) !== bookId) continue;
    if (str_(getByHeader_(r,map,['Decyzja'])) !== 'CURRENT NEXT') continue;
    return {
      date: dateOrString_(getByHeader_(r,map,['Data'])),
      gate: str_(getByHeader_(r,map,['Gate'])),
      preflightMode: str_(getByHeader_(r,map,['Preflight mode'])),
      risk: str_(getByHeader_(r,map,['Risk before check'])),
      continuity: str_(getByHeader_(r,map,['Continuity / spoiler check'])),
      source: str_(getByHeader_(r,map,['Źródło'])),
      prediction: numOrNull_(getByHeader_(r,map,['Prediction snapshot /5'])),
      confidence: numOrNull_(getByHeader_(r,map,['Prediction confidence'])),
      decisionSnapshot: numOrNull_(getByHeader_(r,map,['Decision Score snapshot'])),
      modeSnapshot: str_(getByHeader_(r,map,['Decision Mode snapshot']))
    };
  }
  return {};
}

function readDecision_(ss) {
  const sh = requireSheet_(ss, 'Decision Engine');
  return {
    mode: str_(findLabelValue_(sh, 'Tryb kolejnego wyboru')),
    policy: str_(findLabelValue_(sh, 'Polityka wag')),
    why: str_(findLabelValue_(sh, 'Interpretacja'))
  };
}

function readSession_(ss) {
  const sh = requireSheet_(ss, 'Tryb lektury');
  return {
    mode: str_(findLabelValue_(sh, 'Session Mode')),
    strength: numOrNull_(findLabelValue_(sh, 'Siła')),
    effect: str_(findLabelValue_(sh, 'Efekt')),
    maxAdjustment: numOrNull_(findLabelValue_(sh, 'Max korekta'))
  };
}

function readCoverage_(ss) {
  const sh = requireSheet_(ss, 'Coverage Map');
  const metadataHeader = findHeaderRowByLabels_(sh, ['Pole','Wypełnione','Coverage','Po co']);
  const blindHeader = findHeaderRowByLabels_(sh, ['Kraj','W puli','Przeczytane','Aktywne','Best Decision','Coverage state','Blind Spot Priority']);
  const enrichmentHeader = findHeaderRowByLabels_(sh, ['Priority','Tytuł','Autor','Lifecycle','Decision','Metadata Debt','Braki']);

  const metadata = readRowsUntilBlank_(sh, metadataHeader, 4).map(r => ({
    field: str_(r[0]), filled: numOrNull_(r[1]), coverage: numOrNull_(r[2]),
    coveragePct: numOrNull_(r[2]) == null ? null : numOrNull_(r[2]) * 100
  })).filter(x => x.field);
  const blindSpots = readRowsUntilBlank_(sh, blindHeader, 7).map(r => ({
    country:str_(r[0]), pool:numOrNull_(r[1]), read:numOrNull_(r[2]), active:numOrNull_(r[3]),
    bestDecision:numOrNull_(r[4]), state:str_(r[5]), priority:numOrNull_(r[6])
  })).filter(x => x.country);
  const enrichment = readRowsUntilBlank_(sh, enrichmentHeader, 7).map(r => ({
    priority:numOrNull_(r[0]), title:str_(r[1]), author:str_(r[2]), lifecycle:str_(r[3]),
    decision:numOrNull_(r[4]), metadataDebt:numOrNull_(r[5]), missing:str_(r[6])
  })).filter(x => x.title);
  return {metadata, blindSpots, enrichment};
}

function readCalibration_(ss) {
  const sh = requireSheet_(ss, 'Kalibracja modelu');
  const tests = Number(findLabelValue_(sh, 'Predykcje ocenione')) || 0;
  const history = [];
  const headerRow = findRowByFirstCell_(sh, 'Data');
  if (headerRow && sh.getLastRow() > headerRow) {
    const table = readTable_(sh, headerRow);
    table.rows.forEach(r => {
      const title = str_(getByHeader_(r,table.map,['Książka']));
      if (!title) return;
      history.push({
        date: dateOrString_(getByHeader_(r,table.map,['Data'])),
        title,
        prediction: numOrNull_(getByHeader_(r,table.map,['Predykcja'])),
        actual: numOrNull_(getByHeader_(r,table.map,['Rzeczywista'])),
        delta: numOrNull_(getByHeader_(r,table.map,['Delta'])),
        error: numOrNull_(getByHeader_(r,table.map,['|Błąd|'])),
        classification: str_(getByHeader_(r,table.map,['Klasa zaskoczenia'])),
        confidence: numOrNull_(getByHeader_(r,table.map,['Confidence']))
      });
    });
  }
  return {
    tests,
    mae: numOrNull_(findLabelValue_(sh, 'MAE')),
    rmse: numOrNull_(findLabelValue_(sh, 'RMSE')),
    bias: numOrNull_(findLabelValue_(sh, 'Bias predykcji')),
    hit25: numOrNull_(findLabelValue_(sh, 'Hit ±0,25')),
    hit50: numOrNull_(findLabelValue_(sh, 'Hit ±0,50')),
    state: str_(findLabelValue_(sh, 'Stan')),
    history
  };
}

function readReadingRoom_(ss) {
  const sh = requireSheet_(ss, 'Reading Room');
  const table = readTable_(sh, 4);
  return table.rows.filter(r => str_(getByHeader_(r,table.map,['Notatka użytkownika']))).map(r => ({
    id: str_(getByHeader_(r,table.map,['Note ID'])),
    timestamp: dateOrString_(getByHeader_(r,table.map,['Timestamp'])),
    bookId: str_(getByHeader_(r,table.map,['Book ID'])),
    title: str_(getByHeader_(r,table.map,['Tytuł'])),
    progress: str_(getByHeader_(r,table.map,['Postęp'])),
    type: str_(getByHeader_(r,table.map,['Typ'])),
    note: str_(getByHeader_(r,table.map,['Notatka użytkownika'])),
    context: str_(getByHeader_(r,table.map,['Odpowiedź / kontekst'])),
    modelUse: str_(getByHeader_(r,table.map,['Model use'])),
    status: str_(getByHeader_(r,table.map,['Status'])),
    debriefExtraction: str_(getByHeader_(r,table.map,['Debrief extraction'])),
    spoilerPolicy: str_(getByHeader_(r,table.map,['Spoiler policy']))
  }));
}

function readAchievements_(ss) {
  const sh = requireSheet_(ss, 'Achievementy');
  const table = readTable_(sh, 2);
  return table.rows.filter(r => str_(getByHeader_(r,table.map,['Achievement']))).map(r => ({
    id: str_(getByHeader_(r,table.map,['Achievement ID'])),
    name: str_(getByHeader_(r,table.map,['Achievement'])),
    condition: str_(getByHeader_(r,table.map,['Warunek'])),
    status: str_(getByHeader_(r,table.map,['Status'])),
    progress: str_(getByHeader_(r,table.map,['Postęp'])),
    description: str_(getByHeader_(r,table.map,['Opis'])),
    category: str_(getByHeader_(r,table.map,['Kategoria'])),
    rarity: str_(getByHeader_(r,table.map,['Rzadkość'])),
    xp: numOrNull_(getByHeader_(r,table.map,['XP'])),
    progressValue: numOrNull_(getByHeader_(r,table.map,['Progress Value'])),
    target: numOrNull_(getByHeader_(r,table.map,['Target'])),
    progressPct: numOrNull_(getByHeader_(r,table.map,['Progress %'])),
    secret: bool_(getByHeader_(r,table.map,['Sekret'])),
    icon: str_(getByHeader_(r,table.map,['Ikona'])),
    imageUrl: str_(getByHeader_(r,table.map,['Image URL'])),
    order: Number(getByHeader_(r,table.map,['Sort'])) || 9999,
    unlockedAt: dateOrString_(getByHeader_(r,table.map,['Unlock date'])),
    logic: str_(getByHeader_(r,table.map,['Źródło / logika'])),
    artDirection: str_(getByHeader_(r,table.map,['Art direction']))
  })).sort((a,b)=>a.order-b.order);
}

function readMissions_(ss) {
  const sh = requireSheet_(ss, 'Misje czytelnicze');
  const labels = ['Mission ID','Nazwa','Typ','Pytanie badawcze','Target signal','Reguła kandydata','Priority','Info Gain','Status','Owner opt-in','Completion','Result','Learning Event','Model effect'];
  const headerRow = findHeaderRowByLabels_(sh, labels);
  const table = headerRow ? readTable_(sh, headerRow) : {rows:[],map:{}};
  return table.rows.map(r => ({
    id:str_(getByHeader_(r,table.map,['Mission ID'])), name:str_(getByHeader_(r,table.map,['Nazwa'])), type:str_(getByHeader_(r,table.map,['Typ'])),
    question:str_(getByHeader_(r,table.map,['Pytanie badawcze'])), target:str_(getByHeader_(r,table.map,['Target signal'])), candidateRule:str_(getByHeader_(r,table.map,['Reguła kandydata'])),
    priority:numOrNull_(getByHeader_(r,table.map,['Priority'])), infoGain:numOrNull_(getByHeader_(r,table.map,['Info Gain'])), status:str_(getByHeader_(r,table.map,['Status'])),
    ownerOptIn:bool_(getByHeader_(r,table.map,['Owner opt-in'])), completion:numOrNull_(getByHeader_(r,table.map,['Completion'])), result:str_(getByHeader_(r,table.map,['Result'])),
    learningEvent:str_(getByHeader_(r,table.map,['Learning Event'])), modelEffect:str_(getByHeader_(r,table.map,['Model effect']))
  })).filter(x=>x.id);
}

function readTasteInteractions_(ss) {
  const sh = requireSheet_(ss, 'Interakcje gustu');
  const labels = ['Interaction ID','Cecha A','Relacja','Cecha B','Hipoteza','Evidence +','Evidence -','Support N','Confidence','Status','Model effect','Activation N','Evidence debt','Uwagi'];
  const headerRow = findHeaderRowByLabels_(sh, labels);
  const table = headerRow ? readTable_(sh, headerRow) : {rows:[],map:{}};
  return table.rows.map(r => ({
    id:str_(getByHeader_(r,table.map,['Interaction ID'])), featureA:str_(getByHeader_(r,table.map,['Cecha A'])), relation:str_(getByHeader_(r,table.map,['Relacja'])), featureB:str_(getByHeader_(r,table.map,['Cecha B'])),
    hypothesis:str_(getByHeader_(r,table.map,['Hipoteza'])), positiveEvidence:str_(getByHeader_(r,table.map,['Evidence +'])), negativeEvidence:str_(getByHeader_(r,table.map,['Evidence -'])),
    supportN:numOrNull_(getByHeader_(r,table.map,['Support N'])), confidence:numOrNull_(getByHeader_(r,table.map,['Confidence'])), status:str_(getByHeader_(r,table.map,['Status'])),
    modelEffect:str_(getByHeader_(r,table.map,['Model effect'])), activationN:numOrNull_(getByHeader_(r,table.map,['Activation N'])), evidenceDebt:numOrNull_(getByHeader_(r,table.map,['Evidence debt'])), notes:str_(getByHeader_(r,table.map,['Uwagi']))
  })).filter(x=>x.id);
}

function readRecommendationPostmortem_(ss) {
  const sh = requireSheet_(ss, 'Post-mortem rekomendacji');
  const top = sh.getRange(1,1,Math.min(sh.getLastRow(),4),16).getDisplayValues();
  const adjacent = label => { for (let r=0;r<top.length;r++) for(let c=0;c<top[r].length-1;c++) if(str_(top[r][c])===label) return top[r][c+1]; return ''; };
  const labels = ['Data rekom.','Book ID','Tytuł','Prediction','Pred conf','Decision Score','Mode','Actual','Delta','|Error|','Surprise','Why chosen','What happened','Status','Learning Event','Uwagi'];
  const headerRow=findHeaderRowByLabels_(sh,labels); const table=headerRow?readTable_(sh,headerRow):{rows:[],map:{}};
  const items=table.rows.map(r=>({
    date:dateOrString_(getByHeader_(r,table.map,['Data rekom.'])), bookId:str_(getByHeader_(r,table.map,['Book ID'])), title:str_(getByHeader_(r,table.map,['Tytuł'])),
    prediction:numOrNull_(getByHeader_(r,table.map,['Prediction'])), predictionConfidence:numOrNull_(getByHeader_(r,table.map,['Pred conf'])), decision:numOrNull_(getByHeader_(r,table.map,['Decision Score'])),
    mode:str_(getByHeader_(r,table.map,['Mode'])), actual:numOrNull_(getByHeader_(r,table.map,['Actual'])), delta:numOrNull_(getByHeader_(r,table.map,['Delta'])), error:numOrNull_(getByHeader_(r,table.map,['|Error|'])),
    surprise:str_(getByHeader_(r,table.map,['Surprise'])), whyChosen:str_(getByHeader_(r,table.map,['Why chosen'])), whatHappened:str_(getByHeader_(r,table.map,['What happened'])), status:str_(getByHeader_(r,table.map,['Status'])),
    learningEvent:str_(getByHeader_(r,table.map,['Learning Event'])), notes:str_(getByHeader_(r,table.map,['Uwagi']))
  })).filter(x=>x.bookId);
  return {closed:Number(adjacent('Closed'))||0, waiting:Number(adjacent('Waiting'))||0, bigMisses:Number(adjacent('Big misses'))||0, items};
}

function readSystemHealth_(ss) {
  const sh = requireSheet_(ss, 'System Health');
  const summary = sh.getRange(1,1,Math.min(sh.getLastRow(),4),8).getDisplayValues();
  const overallRow = summary.find(r => str_(r[0]) === 'Overall') || [];
  const headerRow = findHeaderRowByLabels_(sh, ['Check ID','Kategoria','Invariant','Status','Observed','Expected','Severity','Co zrobić']);
  const checks = readRowsUntilBlank_(sh, headerRow, 8).filter(r => r[0]).map(r => ({
    id:str_(r[0]), category:str_(r[1]), invariant:str_(r[2]), status:str_(r[3]), observed:nullable_(r[4]),
    expected:nullable_(r[5]), severity:str_(r[6]), action:str_(r[7])
  }));
  return {
    overall:str_(overallRow[1]) || 'UNKNOWN',
    pass:Number(overallRow[3]) || 0,
    warn:Number(overallRow[5]) || 0,
    fail:Number(overallRow[7]) || 0,
    checks
  };
}

function readDecisionSimulator_(ss) {
  const sh = requireSheet_(ss, 'Decision Simulator');
  const block = sh.getRange(1,1,Math.min(sh.getLastRow(),4),14).getDisplayValues();
  const adjacent = label => {
    for (let r=0;r<block.length;r++) for (let c=0;c<block[r].length-1;c++) if (str_(block[r][c]) === label) return block[r][c+1];
    return '';
  };
  const labels = ['Book ID','Tytuł','Lifecycle','Gate','Core Fit','Read Next','Info Gain','Diversity','Discovery','Freshness','Kraj','Language','Friction','Momentum','AUTO','COMFORT','EXPLORER','POLSKA','LOW FRICTION','FRESH RADAR','SERIES CONTINUE','WILDCARD','AUTO Rank','EXPLORER Rank','WILDCARD Rank','Sygnał'];
  const headerRow = findHeaderRowByLabels_(sh, labels);
  const table = headerRow ? readTable_(sh, headerRow) : {rows:[],map:{}};
  const rows = table.rows.map(r => ({
    id:str_(getByHeader_(r,table.map,['Book ID'])), title:str_(getByHeader_(r,table.map,['Tytuł'])), lifecycle:str_(getByHeader_(r,table.map,['Lifecycle'])), gate:str_(getByHeader_(r,table.map,['Gate'])),
    core:numOrNull_(getByHeader_(r,table.map,['Core Fit'])), readNext:numOrNull_(getByHeader_(r,table.map,['Read Next'])), infoGain:numOrNull_(getByHeader_(r,table.map,['Info Gain'])), diversity:numOrNull_(getByHeader_(r,table.map,['Diversity'])), discovery:numOrNull_(getByHeader_(r,table.map,['Discovery'])), freshness:numOrNull_(getByHeader_(r,table.map,['Freshness'])),
    country:str_(getByHeader_(r,table.map,['Kraj'])), language:str_(getByHeader_(r,table.map,['Language'])), friction:numOrNull_(getByHeader_(r,table.map,['Friction'])), momentum:numOrNull_(getByHeader_(r,table.map,['Momentum'])),
    auto:numOrNull_(getByHeader_(r,table.map,['AUTO'])), comfort:numOrNull_(getByHeader_(r,table.map,['COMFORT'])), explorer:numOrNull_(getByHeader_(r,table.map,['EXPLORER'])), polska:numOrNull_(getByHeader_(r,table.map,['POLSKA'])), lowFriction:numOrNull_(getByHeader_(r,table.map,['LOW FRICTION'])), freshRadar:numOrNull_(getByHeader_(r,table.map,['FRESH RADAR'])), seriesContinue:numOrNull_(getByHeader_(r,table.map,['SERIES CONTINUE'])), wildcard:numOrNull_(getByHeader_(r,table.map,['WILDCARD'])),
    autoRank:numOrNull_(getByHeader_(r,table.map,['AUTO Rank'])), explorerRank:numOrNull_(getByHeader_(r,table.map,['EXPLORER Rank'])), wildcardRank:numOrNull_(getByHeader_(r,table.map,['WILDCARD Rank'])), signal:str_(getByHeader_(r,table.map,['Sygnał']))
  })).filter(x => x.title && x.auto != null).sort((a,b)=>(a.autoRank||9999)-(b.autoRank||9999)).slice(0,40);
  return {
    policy:str_(adjacent('Current policy')), currentNext:str_(adjacent('CURRENT NEXT')), candidates:Number(adjacent('Future candidates'))||rows.length,
    autoTop:str_(adjacent('AUTO #1')), explorerTop:str_(adjacent('EXPLORER #1')), wildcardTop:str_(adjacent('WILDCARD #1')),
    rankShifts:Number(adjacent('Rank shifts ≥10'))||0, disagreement:str_(adjacent('Top disagreement')), rows
  };
}

function readLearningLedger_(ss) {
  const sh = requireSheet_(ss, 'Learning Ledger');
  const block = sh.getRange(1,1,Math.min(sh.getLastRow(),3),14).getDisplayValues();
  const adjacent = label => {
    for (let r=0;r<block.length;r++) for (let c=0;c<block[r].length-1;c++) if (str_(block[r][c]) === label) return block[r][c+1];
    return '';
  };
  const labels = ['Data','Event ID','Book ID','Tytuł','Typ','Signal / Hypothesis','Evidence','Before','After','Confidence','Model effect','Source','Durable?','Uwagi'];
  const headerRow = findHeaderRowByLabels_(sh, labels);
  const table = headerRow ? readTable_(sh, headerRow) : {rows:[],map:{}};
  const items = table.rows.map(r => ({
    date:dateOrString_(getByHeader_(r,table.map,['Data'])), id:str_(getByHeader_(r,table.map,['Event ID'])), bookId:str_(getByHeader_(r,table.map,['Book ID'])), title:str_(getByHeader_(r,table.map,['Tytuł'])), type:str_(getByHeader_(r,table.map,['Typ'])),
    signal:str_(getByHeader_(r,table.map,['Signal / Hypothesis'])), evidence:str_(getByHeader_(r,table.map,['Evidence'])), before:str_(getByHeader_(r,table.map,['Before'])), after:str_(getByHeader_(r,table.map,['After'])), confidence:numOrNull_(getByHeader_(r,table.map,['Confidence'])), effect:str_(getByHeader_(r,table.map,['Model effect'])), source:str_(getByHeader_(r,table.map,['Source'])), durable:str_(getByHeader_(r,table.map,['Durable?'])), notes:str_(getByHeader_(r,table.map,['Uwagi']))
  })).filter(x => x.id).reverse().slice(0,100);
  return {
    events:Number(adjacent('Events'))||items.length, activeHypotheses:Number(adjacent('Active hypotheses'))||0,
    held:Number(adjacent('Held in-reading'))||0, phase:str_(adjacent('Model phase')), trainingN:Number(adjacent('Training n'))||0, items
  };
}

function readUiManifest_(ss) {
  const sh = requireSheet_(ss, 'UI Manifest');
  const moduleHeaders = findHeaderRowsByLabels_(sh, ['Module ID','Etykieta','Enabled','Owner','Expert','Order','Icon','Opis']);
  const metricsHeader = findHeaderRowByLabels_(sh, ['Key','Etykieta','Wartość','Format','Owner','Expert','Order','Opis']);
  const terminologyHeader = findHeaderRowByLabels_(sh, ['Termin techniczny','Widok prosty','Widok ekspercki','Znaczenie']);
  const featuresHeader = findHeaderRowByLabels_(sh, ['Feature','Value','Opis']);

  const modulesById = {};
  moduleHeaders.forEach(headerRow => {
    readUiRows_(sh, headerRow, 8).forEach(r => {
      const id = str_(r[0]);
      if (!id) return;
      modulesById[id] = {
        id, label:str_(r[1]), enabled:bool_(r[2]), owner:bool_(r[3]), expert:bool_(r[4]), order:Number(r[5])||999,
        icon:str_(r[6]), description:str_(r[7])
      };
    });
  });
  const modules = Object.values(modulesById).sort((a,b)=>a.order-b.order);

  const metrics = readUiRows_(sh, metricsHeader, 8).map(r => ({
    key:str_(r[0]), label:str_(r[1]), value:r[2], format:str_(r[3]), owner:bool_(r[4]), expert:bool_(r[5]), order:Number(r[6])||999,
    description:str_(r[7])
  })).filter(x => x.key).sort((a,b)=>a.order-b.order);

  const terminology = {};
  readUiRows_(sh, terminologyHeader, 4).forEach(r => {
    if (r[0]) terminology[str_(r[0])] = {owner:str_(r[1]), expert:str_(r[2]), description:str_(r[3])};
  });

  const features = {};
  readUiRows_(sh, featuresHeader, 3).forEach(r => {
    if (r[0]) features[str_(r[0])] = r[1];
  });
  return {modules, metrics, terminology, features};
}

function readUiRows_(sh, headerRow, width) {
  if (!headerRow || width < 1) return [];
  const startRow = headerRow + 1;
  const lastRow = sh.getLastRow();
  if (startRow > lastRow) return [];
  const values = sh.getRange(startRow,1,lastRow-startRow+1,width).getValues();
  const out = [];
  const boundaries = new Set(['MODULE REGISTRY','KPI REGISTRY','FEATURE FLAGS','MODULE EXTENSIONS']);
  for (let i=0;i<values.length;i++) {
    const row = values[i];
    const first = str_(row[0]);
    const blank = row.every(v => str_(v) === '');
    if (blank || boundaries.has(first) || first.indexOf('TERMINOLOGY —') === 0) break;
    if (first === 'Module ID' || first === 'Key' || first === 'Termin techniczny' || first === 'Feature') break;
    out.push(row);
  }
  return out;
}

function readMedia_(ss) {
  const sh = requireSheet_(ss, 'Media');
  const table = readTable_(sh, 3);
  const out = {};
  table.rows.forEach(r => {
    const id = str_(getByHeader_(r,table.map,['Book ID']));
    if (!id || str_(getByHeader_(r,table.map,['Status'])) === 'DISABLED') return;
    out[id] = {
      coverUrl: str_(getByHeader_(r,table.map,['Cover URL'])),
      sourceUrl: str_(getByHeader_(r,table.map,['Source URL'])),
      source: str_(getByHeader_(r,table.map,['Source'])),
      checked: dateOrString_(getByHeader_(r,table.map,['Checked'])),
      confidence: numOrNull_(getByHeader_(r,table.map,['Confidence'])),
      notes: str_(getByHeader_(r,table.map,['Uwagi']))
    };
  });
  return out;
}

function moduleSpecs_() {
  return {
    tasteFrontier: ['Taste Frontier', 5, false],
    enrichmentEngine: ['Enrichment Engine', 5, true],
    modelArena: ['Model Arena', 5, false],
    antiRut: ['Anti-Rut', 7, false],
    predictionMarket: ['Prediction Market', 5, false],
    paretoShelf: ['Pareto Shelf', 5, false],
    uncertaintyBudget: ['Uncertainty Budget', 5, false],
    robustnessLab: ['Robustness Lab', 5, false],
    afterglow: ['Afterglow', 5, false],
    bookNeighborhoods: ['Book Neighborhoods', 5, false],
    opportunityAging: ['Opportunity Aging', 5, false],
    reviewIntelligence: ['Review Intelligence', 5, false],
    motifPreferenceGraph: ['Motif Preference Graph', 5, false],
    criticCrowdMe: ['Critic Crowd Me', 5, false],
    seriesMap: ['Series Map', 5, false],
    memoryHalfLife: ['Memory Half-life', 5, false],
    undercoverGems: ['Undercover Gems', 5, false],
    explanationDiff: ['Recommendation Explanation Diff', 5, false],
    semanticQuarantine: ['Semantic Quarantine', 5, false],
    sourceCalibration: ['Source Calibration', 5, false],
    crimeDirector: ['Crime Director', 7, false],
    decisionPhysics: ['Decision Physics', 6, false],
    selectorTrust: ['Selector Trust', 5, false],
    policyArena: ['Policy Arena', 5, false],
    preloadRadar: ['Preload Radar', 5, false],
    contentSpectrum: ['Content Spectrum', 5, true],
    contentEvidence: ['Content Evidence', 5, false],
    contentPreference: ['Content Preference', 5, true],
    debriefDirector: ['Debrief Director', 5, true],
    provocationLab: ['Provocation Lab', 5, true],
    readingJourney: ['Reading Journey Lab', 5, true],
    transitionEngine: ['Transition Engine', 5, true],
    characterBond: ['Character Bond Lab', 5, true],
    endingPayoff: ['Ending Payoff Lab', 5, true],
    experiencePalette: ['Experience Palette', 5, true],
    translationSensitivity: ['Translation Sensitivity', 5, false],
    readyShelf: ['Ready Shelf', 5, true],
    acquisitionQueue: ['Acquisition Queue', 5, true],
    characterRegistry: ['Character Registry', 5, false],
    bookCast: ['Book Cast', 5, false],
    characterRelations: ['Character Relations', 5, false],
    characterEvidence: ['Character Evidence', 5, false],
    characterCoverage: ['Character Coverage', 5, false],
    castLoad: ['Cast Load Lab', 5, false],
    characterRecallEngine: ['Character Recall Engine', 5, false],
    identityCollisionLab: ['Identity Collision Lab', 5, false],
    recurringCharacterRadar: ['Recurring Character Radar', 5, false],
    characterProgressSync: ['Character Progress Sync', 5, false],
    characterEncounterTrace: ['Character Encounter Trace', 5, false],
    locationRegistry: ['Location Registry', 5, false],
    bookLocations: ['Book Locations', 5, false],
    suspicionTimeline: ['Suspicion Timeline', 5, false],
    caseLoadMonitor: ['Case Load Monitor', 5, false],
    caseFileAssets: ['Case File Assets', 5, false],
    caseFileDossiers: ['Case File Dossiers', 5, false],
    characterAppearanceEvidence: ['Character Appearance Evidence', 5, false],
    checkpointSnapshots: ['Checkpoint Snapshots', 5, false],
    reentryPackBuilder: ['Re-entry Pack Builder', 5, false],
    caseDelta: ['Case Delta', 5, false],
    characterVisualStates: ['Character Visual States', 5, false],
    visualCollisionBoard: ['Visual Collision Board', 5, false],
    relationGraphFeed: ['Relation Graph Feed', 5, false],
    characterUnlocks: ['Character Unlocks', 5, false],
    characterTheoryPins: ['Character Theory Pins', 5, false],
    suspectWall: ['Suspect Wall', 5, false],
    characterRecallFeedback: ['Character Recall Feedback', 5, false],
    characterMemoryState: ['Character Memory State', 5, false],
    caseboardPlayback: ['Caseboard Playback', 5, false],
    caseSceneState: ['Case Scene State', 5, false],
    dossierAura: ['Dossier Aura', 5, false]
  };
}

function readSelectedModules_(ss, keys) {
  const specs = moduleSpecs_();
  const out = {};
  keys.forEach(key => {
    const spec = specs[key];
    if (!spec) return;
    out[key] = safeModule_(
      () => readModuleSheet_(ss, spec[0], spec[1], spec[2]),
      {sheet:spec[0], title:spec[0], meta:[], headers:[], rows:[], status:'UNAVAILABLE'}
    );
  });
  return out;
}

function readModuleBundle_(ss) {
  return readSelectedModules_(ss, Object.keys(moduleSpecs_()));
}

function readModuleSheet_(ss, sheetName, headerRow, stopAtBlank) {
  const sh = ss.getSheetByName(sheetName);
  if (!sh) return {sheet:sheetName, title:sheetName, meta:[], headers:[], rows:[], status:'MISSING'};
  const lastRow = sh.getLastRow();
  const lastCol = Math.min(sh.getLastColumn(), 90);
  if (lastRow < headerRow || lastCol < 1) return {sheet:sheetName, title:sheetName, meta:[], headers:[], rows:[], status:'EMPTY'};
  const meta = headerRow > 1 ? sh.getRange(1,1,headerRow-1,lastCol).getDisplayValues() : [];
  const headers = sh.getRange(headerRow,1,1,lastCol).getDisplayValues()[0].map(str_);
  const values = lastRow > headerRow ? sh.getRange(headerRow+1,1,lastRow-headerRow,lastCol).getDisplayValues() : [];
  const rows = [];
  for (let i=0;i<values.length;i++) {
    const row = values[i];
    const blank = row.every(v => str_(v) === '');
    if (blank && stopAtBlank) break;
    if (blank || !str_(row[0])) continue;
    const obj = {};
    headers.forEach((h,idx) => { if (h && str_(row[idx]) !== '') obj[h] = row[idx]; });
    rows.push(obj);
  }
  return {
    sheet: sheetName,
    title: meta[0] && meta[0][0] ? str_(meta[0][0]) : sheetName,
    meta,
    headers,
    rows,
    status: 'OK'
  };
}

function lifecycleCounts_(library) {
  const c = { currentNext:0, promote:0, watch:0, bench:0, hold:0, locked:0, retire:0, read:0 };
  const map = {'CURRENT NEXT':'currentNext','PROMOTE':'promote','WATCH':'watch','BENCH':'bench','HOLD':'hold','LOCKED':'locked','RETIRE':'retire','READ':'read'};
  library.forEach(x => { const key = map[x.lifecycle]; if (key) c[key]++; });
  return c;
}

function readTable_(sh, headerRow) {
  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();
  if (lastRow < headerRow || lastCol < 1) return {headers:[], map:{}, rows:[]};
  const headers = sh.getRange(headerRow,1,1,lastCol).getDisplayValues()[0].map(str_);
  const rows = lastRow > headerRow ? sh.getRange(headerRow+1,1,lastRow-headerRow,lastCol).getValues() : [];
  return {headers, map:headerMap_(headers), rows};
}

function headerMap_(headers) {
  const map = {};
  headers.forEach((h,i) => { if (h) map[h] = i; });
  return map;
}

function getByHeader_(row, map, names) {
  for (let i=0;i<names.length;i++) {
    const idx = map[names[i]];
    if (idx !== undefined) return row[idx];
  }
  return '';
}

function findLabelValue_(sh, label) {
  const lastRow = Math.min(sh.getLastRow(), 200);
  if (lastRow < 1) return '';
  const values = sh.getRange(1,1,lastRow,2).getValues();
  for (let i=0;i<values.length;i++) if (str_(values[i][0]) === label) return values[i][1];
  return '';
}

function findRowByFirstCell_(sh, value) {
  const lastRow = Math.min(sh.getLastRow(), 500);
  if (lastRow < 1) return 0;
  const values = sh.getRange(1,1,lastRow,1).getDisplayValues();
  for (let i=0;i<values.length;i++) if (str_(values[i][0]) === value) return i+1;
  return 0;
}

function findHeaderRowByLabels_(sh, labels) {
  const lastRow = Math.min(sh.getLastRow(), 500);
  if (lastRow < 1 || !labels || !labels.length) return 0;
  const width = labels.length;
  const values = sh.getRange(1,1,lastRow,width).getDisplayValues();
  for (let r=0;r<values.length;r++) {
    let match = true;
    for (let c=0;c<width;c++) {
      if (str_(values[r][c]) !== str_(labels[c])) { match = false; break; }
    }
    if (match) return r+1;
  }
  return 0;
}

function findHeaderRowsByLabels_(sh, labels) {
  const lastRow = Math.min(sh.getLastRow(), 500);
  if (lastRow < 1 || !labels || !labels.length) return [];
  const width = labels.length;
  const values = sh.getRange(1,1,lastRow,width).getDisplayValues();
  const rows = [];
  for (let r=0;r<values.length;r++) {
    let match = true;
    for (let c=0;c<width;c++) if (str_(values[r][c]) !== str_(labels[c])) { match = false; break; }
    if (match) rows.push(r+1);
  }
  return rows;
}

function readRowsUntilBlank_(sh, headerRow, width) {
  if (!headerRow || width < 1) return [];
  const startRow = headerRow + 1;
  const lastRow = sh.getLastRow();
  if (startRow > lastRow) return [];
  const values = sh.getRange(startRow,1,lastRow-startRow+1,width).getValues();
  const out = [];
  for (let i=0;i<values.length;i++) {
    const row = values[i];
    const isBlank = row.every(v => str_(v) === '');
    if (isBlank) break;
    out.push(row);
  }
  return out;
}

function safeModule_(fn, fallback) {
  try { return fn(); } catch (err) { return fallback; }
}

function defaultUi_() {
  return {modules:[],metrics:[],terminology:{},features:{owner_mode:true,expert_mode:true,schema_tolerance:true}};
}

function requireSheet_(ss, name) {
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error(`MISSING_SHEET: ${name}`);
  return sh;
}
function str_(v) { return v == null ? '' : String(v); }
function nullable_(v) { return v === '' || v == null ? null : v; }
function numOrNull_(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
function dateOrString_(v) { return v instanceof Date ? v.toISOString() : str_(v); }
function bool_(v) { return v === true || String(v).toUpperCase() === 'TRUE'; }
