Crime Cockpit Local v6.2.1
============================

LINIA ŹRÓDŁOWA
---------------
Ten release powstał bezpośrednio z kompletnego, zaakceptowanego pakietu
crime-cockpit-local-v6.1.0 z Google Drive. v6.1.0 pozostaje rollbackiem.
NOIR MODERN pozostaje visual language; v6 rozszerza istniejący interfejs.

WERSJE
------
- Frontend: 6.2.1
- API schema: 5.2.0
- Minimalny kompatybilny frontend API: 6.2.0
- API pozostaje READ ONLY.

Najważniejsze zmiany v6
-----------------------
1. Vault Presence
   - subtelne „◌” przy książkach bez EPUB-u w właścicielskim Ebook Vault,
   - obecność pliku jest logistyką, nigdy bonusem jakości/Taste Fit/Decision Score,
   - dossier pokazuje brak pliku bez alarmistycznego tonu.

2. Preload Radar
   - wyłapuje brakujące EPUB-y blisko realnej strefy wyboru,
   - PRELOAD SOON = sygnał logistyczny, nie rekomendacja,
   - pressure = lifecycle/rank proximity + nominacje Crime Directora; Gate AUTO PASS obowiązkowy.

3. Crime Director jako osobny widok
   - Shadow Council / aktualne nominacje / urgency,
   - Experience Lanes (Fun vs Depth),
   - Preload Radar,
   - final pick nadal dopiero po CASE CLOSED + debrief + fresh preflight.

4. Dossier Intelligence Profile
   - bezpieczne przed-lekturowe sygnały: Reading Journey, Experience Palette, Character Bond prior, Content state, Translation Sensitivity,
   - Ending Payoff pojawia się tylko dla READ.

5. Backend Atlas
   - ekspercki podgląd nowych modułów i liczby rekordów,
   - schema tolerant; brak opcjonalnego modułu nie wywraca aplikacji.

6. API 5.0
   - Baza książek wystawia jako first-class: Decision Confidence, Confidence Band/Why, Vault fields i Preload fields,
   - nowe moduły: Crime Director, Decision Physics, Selector Trust, Policy Arena, Preload Radar, Content Spectrum/Evidence/Preference, Debrief Director, Provocation Lab, Reading Journey, Transition Engine, Character Bond, Ending Payoff, Experience Palette, Translation Sensitivity, Ready Shelf, Acquisition Queue,
   - generic module reader obsługuje do 90 kolumn (potrzebne m.in. Decision Physics / Content Spectrum).

7. Version Truth
   - footer bierze wersję z runtime FRONTEND_VERSION; brak ręcznie wpisanego v5.0.

Instalacja / update
-------------------
1. Zachowaj crime-cockpit-local-v5.0.1 jako rollback.
2. Skopiuj cały folder crime-cockpit-local-v6.1.0 lokalnie i uruchamiaj index.html z tego kompletnego zestawu.
3. W Apps Script zastąp wyłącznie API Code.gs plikiem apps-script/Code.gs.
4. Deploy > Manage deployments > Edit > New version > Deploy. URL /exec i CRIME_COCKPIT_TOKEN pozostają bez zmian.
5. Odśwież v6.1.0; API powinno raportować schema 5.0.0.
6. Smoke test: Kokpit, Kolejka, Reżyser, Biblioteka, dossier, Klub lekturowy, Laboratorium.
7. Sprawdź CURRENT = Morderstwa w Somerset i System Health = PASS przed uznaniem release za LIVE.

Bezpieczeństwo
--------------
- HARD SERIES / HARD SPOILER CONTINUITY pozostają nadrzędne.
- Ending Payoff nie wystawia ending semantics przed READ.
- Vault ownership nie zmienia jakości książki ani rankingu.
- Translation Sensitivity nie obniża jakości za język.
- Raw ebook text nie jest wystawiany przez API.
- Semantic Quarantine pozostaje nadrzędna dla CURRENT/UNREAD.


CHARACTER INTELLIGENCE v6.1
---------------------------
- widok Postacie z wyszukiwarką po nazwie, aliasie, roli i książce;
- Character Registry + Book Cast + Character Relations + Character Evidence + Character Coverage;
- Who Was That Again? dla CURRENT działa wyłącznie na progress-safe danych;
- pełny named cast z owner EPUB dopiero po READ;
- UNREAD/CURRENT full-text names nie przechodzą przez Semantic Quarantine;
- command palette wyszukuje także postacie;
- dossier książki pokazuje tylko safe-now cast.


CHARACTER CASE FILES v6.2
-------------------------
- rozbudowuje istniejący widok `characters` / `Postacie`; nie tworzy osobnej aplikacji ani alternatywnego frontendu;
- Akta sprawy bieżącej książki: checkpoint, Case Load, portrait-ready count i twarda granica spoilerowa;
- subwidoki: Akta sprawy, Powiązania, Miejsca, Podejrzenia, Wracam do książki, Time Machine;
- frontend korzysta z Case File Dossiers, Encounter Trace, Location Intelligence, Suspicion Timeline, Re-entry Pack, Appearance Evidence, Snapshot i Case Delta;
- dialog postaci ma formę ciemny Cockpit + papierowe dossier, zgodnie z zaakceptowanym kierunkiem wizualnym;
- portrety są wspierane, ale obraz pojawia się tylko gdy backend wystawia realny URL zasobu; bez obrazu pozostaje elegancki monogram / placeholder;
- syntetyczny portret jest zawsze NON-CANONICAL i nigdy nie wraca do Evidence / modelu;
- API 5.2 dodaje nowe arkusze jako first-class generic modules;
- bundle jest przygotowany jako MANUAL DEPLOY / NOT LIVE.


=== v6.2.1 — CHARACTER PORTRAITS ===
- 9 clean synthetic portraits bundled locally under assets/portraits/BK00002/.
- Google Drive remains canonical asset storage; bundle paths are the runtime/offline source.
- Case File Assets maps Character ID -> Drive File ID -> Frontend Asset Path -> SHA256.
- Portraits are synthetic, spoiler-safe to the active checkpoint and explicitly non-canonical.
- Owner-facing Character UI received a small Polish terminology cleanup.
