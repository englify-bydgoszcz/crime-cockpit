# Crime Cockpit

Statyczny frontend projektu Crime Cockpit. Repo jest przygotowane do GitHub Pages.

## Podgląd online
Po utworzeniu repozytorium i włączeniu GitHub Pages wybierz:

- Source: `Deploy from a branch`
- Branch: `main`
- Folder: `/ (root)`

Każdy kolejny push do `main` automatycznie odświeży podgląd Pages.

## Dane LIVE
Publiczne `demo-data.js` jest celowo zanonimizowane / oczyszczone z prywatnych notatek czytelniczych i hipotez.

Dane LIVE są pobierane z Apps Script dopiero po lokalnym ustawieniu w przeglądarce:

- Web App URL
- tokenu API

Te wartości trafiają wyłącznie do `localStorage` przeglądarki i **nie powinny być commitowane do repozytorium**.

## Backend
`apps-script/Code.gs` jest źródłem API. Deployment Apps Script pozostaje ręczny.

## Release
Frontend: 6.3.0
API schema: 5.3.0

## Character Intelligence
Moduł `Postacie` obejmuje m.in.:

- Akta sprawy
- portrety syntetyczne z provenance
- tablicę relacji
- wizualne „Nie pomyl ich”
- mapę miejsc
- ścianę własnych podejrzeń
- model mgły pamięci
- unlocki dossier
- Re-entry Pack
- Checkpoint Time Machine / Caseboard Playback
- warianty wyglądu w różnych okresach

Wszystkie warstwy respektują Spoiler Firewall.
